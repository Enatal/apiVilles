<?php

require "models/VillesManager.class.php";


class VillesController
{
    private $villeManager;

    public function __construct()
    {
        $this->villeManager = new VillesManager();
    }

    /** fontion appelée par la route /ville/{code_postal} */
    public function get_ville_infos($code_postal)
    {
		if (empty(trim($code_postal)) || ! is_code_postal(trim($code_postal))) // code postal doit etre un nombre
		{
			echo json_encode(array("error" => $code_postal." is not a valid postal code")) ;
		}
		else {
			$villes = $this->villeManager->getVillesByCodePostal(trim($code_postal)) ;
			if (empty($villes))
			{
				echo json_encode(array("error" => $code_postal." is not a valid postal code")) ;
			}
			else{
				echo json_encode($villes) ;
			}
		}
    }

	function get_ville_population($code_postal)
	{
		if (empty(trim($code_postal)) || ! is_code_postal(trim($code_postal))) // code postal doit etre un nombre
		{
			echo json_encode(array("error" => $code_postal." is not a valid postal code")) ;
		}
		else {
			$villes = $this->villeManager->get_villes_population(trim($code_postal)) ;
			if (empty($villes))
			{
				echo json_encode(array("error" => $code_postal." is not a valid postal code")) ;
			}
			else{
				echo json_encode($villes) ;
			}
		}
	}

	function get_ville_superficie($code_postal)
	{
		if (empty(trim($code_postal)) || ! is_code_postal(trim($code_postal))) // code postal doit etre un nombre
		{
			echo json_encode(array("error" => $code_postal." is not a valid postal code")) ;
		}
		else {
			$villes = $this->villeManager->get_villes_superficie(trim($code_postal)) ;
			if (empty($villes))
			{
				echo json_encode(array("error" => $code_postal." is not a valid postal code")) ;
			}
			else{
				echo json_encode($villes) ;
			}
		}
	}

	function get_villes_departement($departement, $canton=null)
	{
		if (empty($departement) || ! is_numeric($departement)) // departement doit etre un nombre
		{
			echo json_encode(array("error" => $departement." is not a valid department code")) ;
		}
		else if ($canton != null && ! is_numeric($departement)) // canton doit etre null ou  doit etre un nombre
		{
			echo json_encode(array("error" => $canton." is not a valid county code")) ;
		}
		else {
			$villes = $this->villeManager->getVillesByDepartment($departement, $canton) ;
			if (empty($villes))
			{
				echo json_encode(array("error" => "No result for your request")) ;
			}
			else{
				echo json_encode($villes) ;
			}
		}
	}


	public function update_ville_infos($code_postal)
	{
		if (empty(trim($code_postal)) || ! is_code_postal(trim($code_postal))) // code postal doit etre un nombre
		{
			echo json_encode(array("error" => $code_postal." is not a valid postal code")) ;
		}
		else
		{
			$villes = $this->villeManager->getVillesByCodePostal(trim($code_postal)) ;
			if (empty($villes))
			{
				echo json_encode(array("error" => $code_postal." is not a valid postal code")) ;
			}
			else if (count($villes) > 1){ // plusieurs villes avec un même code postal, on n'update pas
				echo json_encode(array("error" => $code_postal." is not unique, please use postal codes binded ith only one city")) ;
			}
			else
			{
				$nom = null ; if (isset($_POST["nom"])) $nom = htmlspecialchars($_POST["nom"]) ;
				$code_postal = null ; if (isset($_POST["code_postal"])) $code_postal = htmlspecialchars($_POST["code_postal"]) ;
				$departement = null ; if (isset($_POST["departement"])) $departement = htmlspecialchars($_POST["departement"]) ;
				$canton = null ; if (isset($_POST["canton"])) $canton = htmlspecialchars($_POST["canton"]) ;
				$surface = null ; if (isset($_POST["surface"])) $surface = htmlspecialchars($_POST["surface"]) ;
				$population = null ; if (isset($_POST["population"])) $population = htmlspecialchars($_POST["population"]) ;
				$id = null ; if (isset($_POST["id"])) $id = htmlspecialchars($_POST["id"]) ;
				$densite = null ; if (isset($_POST["densite"])) $densite = htmlspecialchars($_POST["densite"]) ;

				$datas = array("nom"=>$nom,
                    "code_postal"=>$code_postal,
                    "departement"=>$departement,
                    "densite"=>$densite,
                    "surface"=>$surface,
                    "canton"=>$canton,
                    "population"=>$population
                );
                $res = $this->villeManager->update_ville($datas) ;
                if ($res)
                {
                    echo json_encode($res) ;
                }
                else{
                    echo json_encode(array("error" => "Unable to update the city with postal code=".$code_postal)) ;
                }

			}
		}
	}
}
