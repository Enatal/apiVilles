<?php

if (!function_exists('is_code_postal')) {

    /** Expression régulière pour tester si une chaine contient un code postal */
    function is_code_postal($str)
    {

        return preg_match ("~^[0-9]{5}$~",$str);
    }
}
