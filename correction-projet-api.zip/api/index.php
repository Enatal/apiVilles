<?php
session_start();

/***** SETTINGS/CONSTANTES *****/
// On définit les différents modes d'accès aux données
define("PDO", 0) ; // connexion par PDO
define("MEDOO", 1) ; // Connexion par Medoo
// Choix du mode de connexion
define("DB_MANAGER", MEDOO); // PDO ou MEDOO
// Création de deux constantes URL et FULL_URL qui pourront servir dans les controlleurs et/ou vues
define("URL", str_replace("index.php", "", (isset($_SERVER['HTTPS']) ? "https" : "http") .
    "://$_SERVER[HTTP_HOST]$_SERVER[PHP_SELF]"));
define("FULL_URL", str_replace("index.php", "", (isset($_SERVER['HTTPS']) ? "https" : "http") .
    "://$_SERVER[HTTP_HOST]/{$_SERVER['REQUEST_URI']}"));


/***** REQUIRES/INCLUDES *****/
// Chargement du framework Medoo
include_once ("./librairies/medoo/Medoo.php");
// on charge les fichiers qui contiennent les fonctions supplémentaires qu'on va utiliser plus tard (les helpers)
require_once "helpers/string_helper.php";
require_once "helpers/villes_helper.php";
// inclusion des controllers
require_once "controllers/VillesController.php";

/****** ROUTING *********/
//réalisation du système de routage
// le fichier .htccess effectue une redirection automatique depuis l'url /nom_de_la_route vers index.php?page=nom_de_la_route
// on va donc gérer notre routage depuis le paramètre $_GET["page"]

// NB : notre API ne retournat que des données en JSON, nous n'utiliserons aucuen vue dans ce projet.
// Les vues seront réalisés dans le projet "testapi", qui "consommera" notre API
// On a donc un MVC sans Vues
try
{
    // si $_GET['page'] est vide alors on retourne une erreur
    if (empty($_GET['page']))
    {
        echo json_encode(array("error" => "Invalid request")) ;
    }
    else // sinon on traite au cas par cas nos routes
    {

        // on décompose le paramètre $_GET['page'] d'après le "/"
        $url = explode("/", filter_var($_GET['page'], FILTER_SANITIZE_URL));
        switch ($url[0]) // on regarde le premier élément de la route
        {
            // route "/ville/{code_postal}" ou potentiellement "/ville/{code_postal}/update (on va traiter les deux cas)"
            case "ville":
				// on récupère ensuite le code postal
				$code_postal = $url[1] ;
				$controller = new VillesController();
				if (count($url) > 2 && $url[2] == "update") // s'il y a le suffixe "/update" on effectue une update
				{
					$controller->update_ville_infos($code_postal);
				}
				else{ // pas d'update. C'est de la recupération de données
					$controller->get_ville_infos($code_postal);
				}
				break;

			// route "/population/{code_postal}"
			case "population":
				// on récupère ensuite le code postal
				$code_postal = $url[1] ;
				$controller = new VillesController();
				$controller->get_ville_population($code_postal);
				break;

			// route "/superficie/{code_postal}"
			case "superficie":
				// on récupère ensuite le code postal
				$code_postal = $url[1] ;
				$controller = new VillesController();
				$controller->get_ville_superficie($code_postal);
				break;

			// route "/villes/{departement}" ou "/villes/{departement}/{canton}", on va traiter les deux cas
			case "villes":
				// on récupère ensuite le departement
				if (count($url) > 1)
				{
					$controller = new VillesController();
					$departement = $url[1];
					// on va aussi tester si l'url contient un numéro de canton
					$canton = null ;
					if (count($url) > 2)
					{
						$canton = $url[2];
					}

					// on appelle le controlleur avec les bons paramètres
					$controller->get_villes_departement($departement, $canton);
				}
				break;



            // route chargée par défaut si aucune autre route n'a été chargée
            default:
                throw new Exception("La page n'existe pas");
        }
    }
} catch (Exception $e) {
    // en cas d'exeption l
    echo $e->getMessage();
}
