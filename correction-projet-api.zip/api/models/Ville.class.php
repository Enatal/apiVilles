<?php
class Ville extends Model implements \JsonSerializable
{
    private $id;
    private $departement;
    private $nom;
	private $canton;
	private $code_postal;
	private $population;
	private $densite;
	private $surface;


    public function __construct($id, $departement, $nom, $canton, $code_postal, $population, $densite, $surface)
    {
        $this->id = $id ;
        $this->departement = $departement ;
        $this->nom = $nom ;
		$this->canton = $canton ;
		$this->code_postal = $code_postal ;
		$this->population = $population ;
		$this->densite = $densite ;
		$this->surface = $surface ;
    }


    /** Fonction qui a pour but de convertir en JSON un objet, en incluant ses attributs private */
	public function jsonSerialize()
	{
		$vars = get_object_vars($this);

		return $vars;
	}

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id): void
    {
        $this->id = $id;
    }

	/**
	 * @return mixed
	 */
	public function getDepartement()
	{
		return $this->departement;
	}

	/**
	 * @param mixed $departement
	 */
	public function setDepartement($departement): void
	{
		$this->departement = $departement;
	}

	/**
	 * @return mixed
	 */
	public function getNom()
	{
		return $this->nom;
	}

	/**
	 * @param mixed $nom
	 */
	public function setNom($nom): void
	{
		$this->nom = $nom;
	}

	/**
	 * @return mixed
	 */
	public function getCanton()
	{
		return $this->canton;
	}

	/**
	 * @param mixed $canton
	 */
	public function setCanton($canton): void
	{
		$this->canton = $canton;
	}

	/**
	 * @return mixed
	 */
	public function getCodePostal()
	{
		return $this->code_postal;
	}

	/**
	 * @param mixed $code_postal
	 */
	public function setCodePostal($code_postal): void
	{
		$this->code_postal = $code_postal;
	}

	/**
	 * @return mixed
	 */
	public function getPopulation()
	{
		return $this->population;
	}

	/**
	 * @param mixed $population
	 */
	public function setPopulation($population): void
	{
		$this->population = $population;
	}

	/**
	 * @return mixed
	 */
	public function getDensite()
	{
		return $this->densite;
	}

	/**
	 * @param mixed $densite
	 */
	public function setDensite($densite): void
	{
		$this->densite = $densite;
	}

	/**
	 * @return mixed
	 */
	public function getSurface()
	{
		return $this->surface;
	}

	/**
	 * @param mixed $surface
	 */
	public function setSurface($surface): void
	{
		$this->surface = $surface;
	}



}