<?php
require_once "Model.class.php";
require_once "Ville.class.php";

/*******
 * Class VillesManager
 * La classe VillesManager a pour vocation de gérer les objets Ville que l'application va créer et manipuler
 */
class VillesManager extends Model
{

    /*************************
     * Fontion qui retourne un tableau contenant la ou les villes ayant un code postal donné
     * @param $code_postal
     * @return array contenant la ou les villes possédant le code postal
     ********************************************/
    public function getVillesByCodePostal($code_postal)
    {
    	$results = array();
    	// on va écrire les requetes à la fois pour PDO et MEDOO
		if (DB_MANAGER == PDO) // version PDO
		{
			$req = $this->getDatabase()->prepare("SELECT * FROM villes_france where code_postal like :code_postal ");
			$req->execute(array("code_postal" => $code_postal));
			$villes = $req->fetchAll(PDO::FETCH_ASSOC);
			$req->closeCursor();
		}
		else if (DB_MANAGER == MEDOO) // version MEDOO
		{
			$villes = $this->getDatabase()->select("villes_france", "*", ["code_postal[~]" => $code_postal]) ;
			if (! is_array($villes))
			{
			    // si la requete n'a retournée qu'un seul résultat on en fait quand même un tableau
                // afin d'avoir quelque chose chose de toujours homogène
				$villes = array($villes) ;
			}
		}


		// on a récupéré les villes, on en fait des objets Ville et on retourne le résultat
		foreach ($villes as $ville) {
			$new_ville = new Ville(
				$ville['id'],
				$ville['departement'],
				$ville['nom'],
				$ville['canton'],
				$ville['code_postal'],
				$ville['population'],
				$ville['densite'],
				$ville['surface']
			);
			array_push($results, $new_ville);
		}
		return $results ;
    }


    /***********************************
     * Fonction qui retourne toutes les villes d'un département ou celles du coup département/canton
     * si le canton est précisé
     * @param $departement
     * @param null $canton
     * @return array
     **************************************/
	public function getVillesByDepartment($departement, $canton=null)
	{
		$results = array();
		if (DB_MANAGER == PDO) // version PDO
		{
		    $datas = array("departement" => $departement);
			$query = "SELECT * FROM villes_france where departement = :departement " ;
			if ($canton != null)
			{
				$query = $query." AND canton = :canton" ;
				$datas["canton"] = $canton ;
			}
			$req = $this->getDatabase()->prepare($query);
			$req->execute($datas);
			$villes = $req->fetchAll(PDO::FETCH_ASSOC);
			$req->closeCursor();
		}
		else if (DB_MANAGER == MEDOO) // version MEDOO
		{
			$datas = array("departement" => $departement) ;
			if ($canton != null)
			{
				$datas["canton"] = $canton ;
			}
			$villes = $this->getDatabase()->select("villes_france", "*", $datas) ;
			//var_dump($villes);
			if (! is_array($villes))
			{
				$villes = array($villes) ;
			}
		}

        // on a récupéré les villes, on en fait des objets Ville et on retourne le résultat
		foreach ($villes as $ville) {
			$new_ville = new Ville(
				$ville['id'],
				$ville['departement'],
				$ville['nom'],
				$ville['canton'],
				$ville['code_postal'],
				$ville['population'],
				$ville['densite'],
				$ville['surface']
			);
			//var_dump($new_ville);
			array_push($results, $new_ville);
		}
		//var_dump($results);
		return $results ;
	}

    function get_villes_population($code_postal)
	{
		// on réutilise notre méthode qui récupérait les villes d'après le code postal
		$villes = $this->getVillesByCodePostal($code_postal) ;
		$results = array() ;
		foreach ($villes as $ville) {
			$item = array();
			$item["nom"] = $ville->getNom() ;
			$item["population"] = $ville->getPopulation() ;
			array_push($results, $item);
		}
		return $results ;
	}

	function get_villes_superficie($code_postal)
	{
		// on réutilise notre méthode qui récupérait les villes d'après le code postal
		$villes = $this->getVillesByCodePostal($code_postal) ;
		$results = array() ;
		foreach ($villes as $ville) {
			$item = array();
			$item["nom"] = $ville->getNom() ;
			$item["surface"] = $ville->getSurface() ;
			array_push($results, $item);
		}
		return $results ;
	}


    /****************************************
     * Fonction qui met à jour une ville d'après les données contenues dans le tableau $datas
     * @param $datas
     * @return array|false
     *****************************************/
	function update_ville($datas)
    {
        if (isset($datas["code_postal"]))
        {
            // tout d'abord on veut vérifier que le code postal correspond bien à une ville
            $villes = $this->getVillesByCodePostal($datas["code_postal"]) ;
            if (count($villes) != 1)
            {
                // on a aussi décidé qu'on ne mettrait à jour qu'une ville qui est seule à être identifiable par ce code postal
                return false ;
            }
            else
            {
                $ville = $villes[0] ;
                $id = $ville->getId();
                if (DB_MANAGER == PDO) // version PDO
                {
                    $query = "UPDATE villes_france SET nom=:nom, 
                         code_postal=:code_postal, 
                         densite=:densite, 
                         population=:population, 
                         canton=:canton, 
                         surface=:surface,
                         departement=:departement 
                        where code_postal = :code_postal" ;
                    $req = $this->getDatabase()->prepare($query);
                    $req->execute($datas);
                    $req->closeCursor();
                }
                else if (DB_MANAGER == MEDOO) // version MEDOO
                {
                    $this->getDatabase()->update("villes_france", $datas, ["id"=>$id]) ;
                }
                // si la mise à jour a été effectuée, en renvoie la ville modifiée
                return $this->getVillesByCodePostal($datas["code_postal"]) ;
            }
        }
    }
}
