<?php


class TestController
{


    public function __construct()
    {

    }


    /****************
     * Fonction appelée pour les erreurs 404
     */
    public function error404()
    {
        require_once "views/404.php";
    }

    public function display_city_infos($code_postal=null)
    {
        $villes = array() ;
        if ($code_postal != null)
        {
            // on fait un appel GET à notre API pour récupérer les données en JSON
            $json = file_get_contents(URL_API."ville/".$code_postal);
            $villes = json_decode($json) ; // on transforme le JSON en objet
            if (is_array($villes)) // si on a bien un tableau alors le résultat est bon
            {
                // on applique le tri sur notre tableau en utilisant la fonction qu'on a mis dans notre helper "villes_helper"
                usort($villes, "cmp");
            }
            else if (isset($villes->error)) // sinon cest qu'on a une erreur, on l'affichera
            {
                $error = $villes->error ;
            }
        }
        // et on charge la vue
        require_once "views/villes-cp.php";
    }

    public function display_cities_departement($departement=null)
    {
        $villes = array() ;
        if ($departement != null)
        {
            // on fait un appel GET à notre API pour récupérer les données en JSON
            $json = file_get_contents(URL_API."villes/".str_pad($departement, 2, '0', STR_PAD_LEFT));
            $villes = json_decode($json) ;// on transforme le JSON en objet
            if (is_array($villes))// si on a bien un tableau alors le résultat est bon
            {
                // on applique le tri sur notre tableau
                usort($villes, "cmp");
            }
            else if (isset($villes->error)) // sinon cest qu'on a une erreur, on l'affichera
            {
                $error = $villes->error ;
            }
        }
        // et on charge la vue
        require_once "views/villes-departement.php";
    }

    public function display_cities_canton($departement=null, $canton=null)
    {
        $villes = array() ;
        if ($departement != null && $canton != null)
        {
            // on fait un appel GET à notre API pour récupérer les données en JSON
            $json = file_get_contents(URL_API."villes/".str_pad($departement, 2, '0', STR_PAD_LEFT)."/".str_pad($canton, 2, '0', STR_PAD_LEFT));
            $villes = json_decode($json) ;// on transforme le JSON en objet
            if (is_array($villes))// si on a bien un tableau alors le résultat est bon
            {
                // on applique le tri sur notre tableau
                usort($villes, "cmp");
            }
            else if (isset($villes->error)) // sinon cest qu'on a une erreur, on l'affichera
            {
                $error = $villes->error ;
            }
        }
        // et on charge la vue
        require_once "views/villes-canton.php";
    }

    public function display_city_population($code_postal=null)
    {
        $villes = array() ;
        if ($code_postal != null)
        {
            // on fait un appel GET à notre API pour récupérer les données en JSON
            $json = file_get_contents(URL_API."population/".$code_postal);
            $villes = json_decode($json) ;// on transforme le JSON en objet
            if (is_array($villes))// si on a bien un tableau alors le résultat est bon
            {
                // on applique le tri sur notre tableau
                usort($villes, "cmp");
            }
            else if (isset($villes->error)) // sinon cest qu'on a une erreur, on l'affichera
            {
                $error = $villes->error ;
            }
        }
        // et on charge la vue
        require_once "views/villes-population.php";
    }

    public function display_city_superficie($code_postal=null)
    {
        $villes = array() ;
        if ($code_postal != null)
        {
            // on fait un appel GET à notre API pour récupérer les données en JSON
            $json = file_get_contents(URL_API."superficie/".$code_postal);
            $villes = json_decode($json) ;// on transforme le JSON en objet
            if (is_array($villes))// si on a bien un tableau alors le résultat est bon
            {
                // on applique le tri sur notre tableau
                usort($villes, "cmp");
            } else if (isset($villes->error)) // sinon cest qu'on a une erreur, on l'affichera
            {
                $error = $villes->error ;
            }

        }
        // et on charge la vue
        require_once "views/villes-superficie.php";
    }


    /******************************************
     * Fonction un peu différente qui récupère les données dans l'actuel POST pour envoyer une requête
     * de mise à jours à l'API. Si la mise à jour réussit, la ville modifiée est renvoyée comme réponse
     * et on peut l'afficher
     * @param null $code_postal
     */
    public function update_city($code_postal=null)
    {
        if ($code_postal != null)
        {
            // On récupère les données du POST qu'on nettoie
            $nom = null ; if (isset($_POST["nom"])) $nom = htmlspecialchars($_POST["nom"]) ;
            $departement = null ; if (isset($_POST["departement"])) $departement = htmlspecialchars($_POST["departement"]) ;
            $canton = null ; if (isset($_POST["canton"])) $canton = htmlspecialchars($_POST["canton"]) ;
            $surface = null ; if (isset($_POST["surface"])) $surface = htmlspecialchars($_POST["surface"]) ;
            $population = null ; if (isset($_POST["population"])) $population = htmlspecialchars($_POST["population"]) ;
            $densite = null ; if (isset($_POST["densite"])) $densite = htmlspecialchars($_POST["densite"]) ;

            $datas = array("nom"=>$nom,
                "code_postal"=>$code_postal,
                "departement"=>$departement,
                "densite"=>$densite,
                "surface"=>$surface,
                "canton"=>$canton,
                "population"=>$population
                );
            // on envoie la requête à l'API en POST !!! Sinon update impossible
            $json = post(URL_API."ville/".$code_postal."/update", $datas);
            $villes = json_decode($json) ;// on transforme le JSON en objet
            if (is_array($villes))// si on a bien un tableau alors le résultat est bon
            {
                // on applique le tri sur notre tableau
                usort($villes, "cmp");
            }
            else if (isset($villes->error)) // sinon cest qu'on a une erreur, on l'affichera
            {
                $error = $villes->error ;
            }
        }
        // et on charge la vue
        require_once "views/ville-update.php";
    }
}
