<?php

if (!function_exists('post')) {

    /***********************************
     * Fonction qui effectue une requete POST vers une url, avec un tableau de paramètres
     * @param $url
     * @param array $fields
     * @return bool|string
     ******************************************/
    function post($url, $fields = array())
    {
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($fields));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }
}

