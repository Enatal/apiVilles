<?php

if (!function_exists('is_code_postal')) {

    /** return true if the string $str contains a postal code */
    function is_code_postal($str)
    {

        return preg_match ("~^[0-9]{5}$~",$str);
    }
}


if (!function_exists('cmp')) {

    /**************************************************
     * Fonction de comparasion alphabétique entre deux objets basés sur leur nom
     * @param $a
     * @param $b
     * @return int
     *****************************************************/
    function cmp($a, $b) {
        return strcmp($a->nom, $b->nom);
    }
}
