<?php
session_start();

/***** SETTINGS/CONSTANTES *****/
// Création de deux constantes URL et FULL_URL qui pourront servir dans les controlleurs et/ou vues
define("URL", str_replace("index.php", "", (isset($_SERVER['HTTPS']) ? "https" : "http") .
    "://$_SERVER[HTTP_HOST]$_SERVER[PHP_SELF]"));
define("FULL_URL", str_replace("index.php", "", (isset($_SERVER['HTTPS']) ? "https" : "http") .
    "://$_SERVER[HTTP_HOST]/{$_SERVER['REQUEST_URI']}"));

define("URL_API", "http://localhost/api/"); //TODO Url de l'API - à adapter si votre API est située ailleurs


/***** REQUIRES/INCLUDES *****/
// on charge le fichier qui contient les fonctions supplémentaires qu'on va utiliser dans la vue
require_once "helpers/string_helper.php";
require_once "helpers/villes_helper.php";
require_once "helpers/post_helper.php";
// inclusion des controllers
require_once "controllers/TestController.php";


// NB : dans ce projet qui n'a pour vocation que de tester l'API en faisant des appels et en mettant en forme les
// résultats via des vues, nous n'avons ici pas besoin du modèle
// Le modèle est manipulé par l'API, ici nous manipulons le JSON renvoyé par l'API
// On a donc un MVC sans Modèle


/****** ROUTING *********/
//réalisation du système de routage
// le fichier .htccess effectue une redirection automatique depuis l'url /nom_de_la_route vers index.php?page=nom_de_la_route
// on va donc gérer notre routage depuis le paramètre $_GET["page"]
try
{
    // si $_GET['page'] est vide alors on charge la page persnnalisée pour les erreurs 404
    if (empty($_GET['page']))
    {
        $controller = new TestController();
        $controller->error404();
    }
    else // sinon on traite au cas par cas nos routes
    {

        // on décompose le paramètre $_GET['page'] d'après le "/"
        $url = explode("/", filter_var($_GET['page'], FILTER_SANITIZE_URL));
        switch ($url[0]) // on regarde le premier élément de la route
        {

            // dans toutes les routes suivantes on va à chaque fois accepter le cas où le code postal est passé en paramètre
            // ainsi on pourra soit charger la page directement en GET soit utiliser le formulaire et chercher la ville qu'on veut en POST
            case "ville":
                $controller = new TestController();
                $code_postal=null ;
                if (count($url) > 1)
                {
                    $code_postal = $url[1] ;
                }
                if (isset($_POST["code_postal"]))
                {
                    $code_postal = htmlspecialchars($_POST["code_postal"]);
                }
                $controller->display_city_infos($code_postal);
                break;

            case "departement":
                $controller = new TestController();
                $departement=null ;
                if (count($url) > 1)
                {
                    $departement = $url[1] ;
                }
                if (isset($_POST["departement"]))
                {
                    $departement = htmlspecialchars($_POST["departement"]);
                }
                $controller->display_cities_departement($departement);
                break;

            case "canton":
                $controller = new TestController();
                $departement=null ;
                $canton=null ;
                if (count($url) > 1)
                {
                    $departement = $url[1] ;
                }
                if (isset($_POST["departement"]))
                {
                    $departement = htmlspecialchars($_POST["departement"]);
                }
                if (count($url) > 2)
                {
                    $canton = $url[2] ;
                }
                if (isset($_POST["canton"]))
                {
                    $canton = htmlspecialchars($_POST["canton"]);
                }

                $controller->display_cities_canton($departement, $canton);
                break;

            case "population":
                $controller = new TestController();
                $code_postal=null ;
                if (count($url) > 1)
                {
                    $code_postal = $url[1] ;
                }
                if (isset($_POST["code_postal"]))
                {
                    $code_postal = htmlspecialchars($_POST["code_postal"]);
                }
                $controller->display_city_population($code_postal);
                break;


            case "superficie":
                $controller = new TestController();
                $code_postal=null ;
                if (count($url) > 1)
                {
                    $code_postal = $url[1] ;
                }
                if (isset($_POST["code_postal"]))
                {
                    $code_postal = htmlspecialchars($_POST["code_postal"]);
                }
                $controller->display_city_superficie($code_postal);
                break;

            case "update":
                $controller = new TestController();
                $code_postal=null ;
                if (count($url) > 1)
                {
                    $code_postal = $url[1] ;
                }
                if (isset($_POST["code_postal"]))
                {
                    $code_postal = htmlspecialchars($_POST["code_postal"]);
                }
                $controller->update_city($code_postal);
                break;

            // route chargée par défaut si aucune autre route n'a été chargée
            default:
                $controller = new TestController();
                $controller->error404();
        }
    }
} catch (Exception $e) {
    // en cas d'exeption l
    echo $e->getMessage();
}
