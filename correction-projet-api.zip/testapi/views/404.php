<!DOCTYPE HTML>
<html>
<?php require_once "views/common/header.php"; ?>
<body class="is-preload">

<?php require_once "views/common/navbar.php"; ?>

<!-- Wrapper -->
<div id="wrapper">

    <!-- Main -->
    <section id="main" class="wrapper">
        <div class="inner">
            <div class="error col-12"> La page que vous essayez d'atteindre n'existe pas</div>
        </div>
    </section>

</div>

<?php require_once "views/common/footer.php"; ?>
</body>
</html>