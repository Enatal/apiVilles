
        <!-- Footer -->
			<footer id="footer" class="wrapper alt">
				<div class="inner">
					<ul class="menu">
						<li>&copy; Infovilles.fr. Tous droits réservés.</li>
					</ul>
				</div>
			</footer>

		<!-- Scripts -->
			<script src="<?= URL ?>public/assets/js/jquery.min.js"></script>
			<script src="<?= URL ?>public/assets/js/jquery.scrollex.min.js"></script>
			<script src="<?= URL ?>public/assets/js/jquery.scrolly.min.js"></script>
			<script src="<?= URL ?>public/assets/js/browser.min.js"></script>
			<script src="<?= URL ?>public/assets/js/breakpoints.min.js"></script>
			<script src="<?= URL ?>public/assets/js/util.js"></script>
			<script src="<?= URL ?>public/assets/js/main.js"></script>