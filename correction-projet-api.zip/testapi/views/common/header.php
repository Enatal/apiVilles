<head>
    <title>Infos démographiques</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="<?= URL ?>public/assets/css/main.css" />
    <link rel="stylesheet" href="<?= URL ?>public/assets/css/custom.css" />
    <noscript><link rel="stylesheet" href="<?= URL ?>public/assets/css/noscript.css" /></noscript>
</head>