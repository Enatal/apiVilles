<!-- Header -->
<header id="header">
    <a href="index" class="title">Infovilles - Infos démographiques</a>
    <nav>
        <ul>
            <li><a href="<?= URL ?>ville" class="<?= str_contains(FULL_URL, "ville") ? "active" : "" ?>">Ville</a></li>
            <li><a href="<?= URL ?>population"  class="<?= str_contains(FULL_URL, "population") ? "active" : "" ?>">Population</a></li>
            <li><a href="<?= URL ?>superficie"  class="<?= str_contains(FULL_URL, "superficie") ? "active" : "" ?>">Superficie</a></li>
            <li><a href="<?= URL ?>departement" class="<?= str_contains(FULL_URL, "departement") ? "active" : "" ?>">Par département</a></li>
            <li><a href="<?= URL ?>canton"  class="<?= str_contains(FULL_URL, "canton") ? "active" : "" ?>">Par canton</a></li>
            <li><a href="<?= URL ?>update"  class="<?= str_contains(FULL_URL, "update") ? "active" : "" ?>">Mettre à jour</a></li>
        </ul>
    </nav>
</header>