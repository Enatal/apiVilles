<!DOCTYPE HTML>
<html>
<?php require_once "views/common/header.php"; ?>
<body class="is-preload">

<?php require_once "views/common/navbar.php"; ?>

<div class="container">
    <!-- Wrapper -->
    <div id="wrapper">

        <!-- Main -->
        <section id="main" class="wrapper">
            <div class="inner">
                <?php if (isset($error)) { ?><div class="error col-12"> <?= $error ?> </div><?php }
                else if (isset($villes)) { ?><div class="success col-12"> Mise à jour effectuée avec succès </div><?php } ?>
                <h2>Saisissez les informations à modifier en base de données</h2>
                <p>Par souci de clarté, nous avons fait le choix de ne proposer la mise que des villes possédant un code postal
                    non partagé avec d'autres villes. Autrement dit, les villes pouvant être identifié par leur code postal.</p>
                <form method="post" action="<?= URL."update"?>">
                    <div class="row gtr-uniform">
                        <div class="col-12">
                            <input type="text" name="nom" id="nom" value="" placeholder="Nom de la ville" />
                        </div>
                        <div class="col-4">
                            <input type="text" name="departement" id="departement" value="" placeholder="Département" />
                        </div>
                        <div class="col-4">
                            <input type="text" name="canton" id="canton" value="" placeholder="Numéro de canton (01,02, ...)" />
                        </div>
                        <div class="col-4">
                            <input type="text" name="code_postal" id="code_postal" value="" placeholder="Code postal" />
                        </div>

                        <div class="col-4">
                            <input type="text" name="population" id="population" value="" placeholder="Population" />
                        </div>
                        <div class="col-4">
                            <input type="text" name="surface" id="surface" value="" placeholder="Superficie (km²)" />
                        </div>
                        <div class="col-4">
                            <input type="text" name="densite" id="densite" value="" placeholder="Densité de population (hab/km²)" />
                        </div>
                        <div class="col-12">
                            <ul class="actions">
                                <li><input type="submit" value="Envoyer" class="primary" /></li>
                            </ul>
                        </div>
                    </div>
                </form>
                <?php if (isset($code_postal)) { ?>
                <h1 class="major">Informations des villes ayant le code postal <?= $code_postal ?></h1>
                <!-- Table -->
                    <div class="table-wrapper">
                        <table>
                            <thead>
                            <tr>
                                <th>Id</th>
                                <th>Nom de ville</th>
                                <th>Code Postal</th>
                                <th>Département</th>
                                <th>Canton</th>
                                <th>Population</th>
                                <th>Superficie (km²)</th>
                                <th>Densité (hab/km²)</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            if (isset($villes) && is_array($villes))
                            {
                            // $users est défini dans le controlleur, on peut l'utiliser dans la vue
                            foreach ($villes as $ville)
                            {
                                if (is_object($ville)) {

                                ?>
                                <tr>
                                    <td><?= $ville->id ?></td>
                                    <td><?= $ville->nom ?></td>
                                    <td><?= $ville->code_postal ?></td>
                                    <td><?= $ville->departement ?></td>
                                    <td><?= $ville->canton ?></td>
                                    <td><?= $ville->population ?></td>
                                    <td><?= $ville->surface ?></td>
                                    <td><?= $ville->densite ?></td>
                                </tr>
                            <?php
                                }
                            }
                            } ?>
                            </tbody>
                        </table>
                    </div>
                <?php } ?>

            </div>
        </section>

    </div>
</div>
<?php require_once "views/common/footer.php"; ?>
</body>
</html>