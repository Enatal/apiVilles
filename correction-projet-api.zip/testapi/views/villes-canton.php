<!DOCTYPE HTML>
<html>
<?php require_once "views/common/header.php"; ?>
<body class="is-preload">

<?php require_once "views/common/navbar.php"; ?>

<div class="container">
    <!-- Wrapper -->
    <div id="wrapper">

        <!-- Main -->
        <section id="main" class="wrapper">
            <div class="inner">
                <?php if (isset($error)) { ?><div class="error col-12"> <?= $error ?> </div><?php } ?>
                <h2>Saisissez un code de departement et un code de canton</h2>
                <form method="post" action="<?= URL."canton"?>">
                    <div class="row gtr-uniform">
                        <div class="col-6">
                            <input type="text" name="departement" id="departement" value="" placeholder="Département" />
                        </div>
                        <div class="col-6">
                            <input type="text" name="canton" id="canton" value="" placeholder="Numéro de canton (01,02, ...)" />
                        </div>
                        <div class="col-12">
                            <ul class="actions">
                                <li><input type="submit" value="Rechercher" class="primary" /></li>
                            </ul>
                        </div>
                    </div>
                </form>
                <?php if (isset($departement)) { ?>
                <h2 class="major">Liste des villes du département <?= $departement ?> et canton <?= $canton ?></h2>
                <!-- Table -->
                    <div class="table-wrapper">
                        <table>
                            <thead>
                            <tr>
                                <th>Id</th>
                                <th>Nom de ville</th>
                                <th>Code Postal</th>
                                <th>Département</th>
                                <th>Canton</th>
                                <th>Population</th>
                                <th>Superficie (km²)</th>
                                <th>Densité (hab/km²)</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            // $users est défini dans le controlleur, on peut l'utiliser dans la vue
                            foreach ($villes as $ville)
                            {
                                if (is_object($ville)) {

                                ?>
                                <tr>
                                    <td><?= $ville->id ?></td>
                                    <td><?= $ville->nom ?></td>
                                    <td><?= $ville->code_postal ?></td>
                                    <td><?= $ville->departement ?></td>
                                    <td><?= $ville->canton ?></td>
                                    <td><?= $ville->population ?></td>
                                    <td><?= $ville->surface ?></td>
                                    <td><?= $ville->densite ?></td>
                                </tr>
                            <?php
                                }
                            } ?>
                            </tbody>
                        </table>
                    </div>
                <?php } ?>

            </div>
        </section>

    </div>
</div>
<?php require_once "views/common/footer.php"; ?>
</body>
</html>