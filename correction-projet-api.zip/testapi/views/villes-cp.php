<!DOCTYPE HTML>
<html>
<?php require_once "views/common/header.php"; ?>
<body class="is-preload">

<?php require_once "views/common/navbar.php"; ?>

<!-- Wrapper -->
<div id="wrapper">

    <!-- Form -->
    <section>

    </section>

    <!-- Main -->
    <section id="main" class="wrapper">
        <div class="inner">
            <?php if (isset($error)) { ?><div class="error col-12"> <?= $error ?> </div><?php } ?>
            <h2>Saisissez un code postal</h2>
            <form method="post" action="<?= URL."ville"?>">
                <div class="row gtr-uniform">
                    <div class="col-12">
                        <input type="text" name="code_postal" id="code_postal" value="" placeholder="Code postal" />
                    </div>

                    <div class="col-12">
                        <ul class="actions">
                            <li><input type="submit" value="Rechercher" class="primary" /></li>
                        </ul>
                    </div>
                </div>
            </form>
            <?php if (isset($code_postal)) { ?>
            <h1 class="major">Liste des villes ayant le code postal <?= $code_postal ?></h1>
            <!-- Table -->
                <div class="table-wrapper">
                    <table>
                        <thead>
                        <tr>
                            <th>Id</th>
                            <th>Nom de ville</th>
                            <th>Code Postal</th>
                            <th>Département</th>
                            <th>Canton</th>
                            <th>Population</th>
                            <th>Superficie (km²)</th>
                            <th>Densité (hab/km²)</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        // $users est défini dans le controlleur, on peut l'utiliser dans la vue
                        foreach ($villes as $ville)
                        {
                            if (is_object($ville)) {

                            ?>
                            <tr>
                                <td><?= $ville->id ?></td>
                                <td><?= $ville->nom ?></td>
                                <td><?= $ville->code_postal ?></td>
                                <td><?= $ville->departement ?></td>
                                <td><?= $ville->canton ?></td>
                                <td><?= $ville->population ?></td>
                                <td><?= $ville->surface ?></td>
                                <td><?= $ville->densite ?></td>
                            </tr>
                        <?php
                            }
                        } ?>
                        </tbody>
                    </table>
                </div>
            <?php } ?>

        </div>
    </section>

</div>

<?php require_once "views/common/footer.php"; ?>
</body>
</html>